//
//  operation.c
//  Assignment5
//
//  Created by Ore Obiyomi on 2015-12-03.
//  Copyright © 2015 Ore Obiyomi. All rights reserved.
//

#include <stdio.h>
#include <stdlib.h>
#include "operation_function.h"

void printOut(struct complex_tag *numba);

int main(int arg, char *argv[])
{
    // Initial structs to be used
    struct complex_tag uno, dos, quotient;
    
    // Prompt use to enter values
    uno.real = atof(argv[1]);
    uno.imaginary = atof(argv[2]);
    dos.real = atof(argv[3]);
    dos.imaginary = atof(argv[4]);

    
    // Display values
    printOut(&uno);
    
    printOut(&dos);
    
    // Multiplication function, with a return type of Complex_type
    Complex_type mult = multiplication(uno, dos);
    
    printf("\nThe product of the complex numbers are: %.3lf + %.3lfi\n", mult.real, mult.imaginary);
    
    // Return value for division function
    int sum = division(&uno, &dos, &quotient);
    
    
    
    // If division was successful, print out values
    if (sum == 0)
    {
        printf("\nThe quotient of the complex numbers are: %.3lf + %.3lfi\n", quotient.real, quotient.imaginary);
    }
    
    // else print division was unsuccessful
    
    // Variables for the add/subtract functions
    struct complex_tag add, sub;
    struct complex_tag *ptr1 = &add, *ptr2 = &sub;
    struct complex_tag **add1 = &ptr1, **sub1 = &ptr2;
    
    // Display return value for add/subtract functions and new complex numbers
    int sum2 = sumAndDifference(uno, dos, add1, sub1);
    
    if (sum2 == 0)
    {
        printf("\nThe sum of the complex numbers are: %.3lf + %.3lfi\n", (*add1)->real, (*add1)->imaginary);
        
        printf("\nThe difference of the complex numbers are: %.3lf + %.3lfi\n", (*sub1)->real, (*sub1)->imaginary);
    }
}

/*function for printing*/
void printOut(struct complex_tag *numba)
{
    double realz = numba->real;
    double imaginaryz = numba->imaginary;
    printf("%f + i %f \n", realz, imaginaryz);
}

