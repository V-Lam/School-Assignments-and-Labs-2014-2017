//
//  operation_function.h
//  Vivian5
//
//  Created by Ore Obiyomi on 2015-12-04.
//  Copyright © 2015 Ore Obiyomi. All rights reserved.
//

#ifndef operation_function_h
#define operation_function_h

#include <stdio.h>

struct complex_tag
{
    double real;
    double imaginary;
};

typedef struct
{
    double real;
    double imaginary;
}Complex_type;



//part c)
Complex_type multiplication(struct complex_tag c1, struct complex_tag c2);


//part d)
int division(struct complex_tag *pointerOne, struct complex_tag *pointerTwo, struct complex_tag *pointerThree);


//part e)
int sumAndDifference(struct complex_tag c1, struct complex_tag c2, struct complex_tag **pointerOne, struct complex_tag **pointerTwo);

#endif /* operation_function_h */
