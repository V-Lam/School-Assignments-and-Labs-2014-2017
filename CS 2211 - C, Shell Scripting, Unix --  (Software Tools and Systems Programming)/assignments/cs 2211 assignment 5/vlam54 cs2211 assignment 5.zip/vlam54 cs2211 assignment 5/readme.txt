Please enter the following command to compile and create the output files:
	make all

to test the program via makefile, you can enter the command:
	make test

or, (after creating the files via make) you can run the output file "operation" and enter in arguments:
	operation arg1 arg2 arg3 arg 4

use the following command to clear the directory of the .o files
	make clean