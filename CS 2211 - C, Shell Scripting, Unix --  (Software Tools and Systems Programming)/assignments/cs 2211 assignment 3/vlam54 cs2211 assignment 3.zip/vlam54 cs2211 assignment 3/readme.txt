Please enter the following commands for each question to correctly compile them. Also please run the respective output name for each question

question 1:
gcc -std=c99 -o prog1 program1.c

question 2:
gcc -std=c99 -o prog2 program2.c

question 3:
gcc -std=c99 -o prog3 program3.c
