Hello,

Again in this assignment I included the javadoc, even though it is not required.

Please ensure that the you have the following java files:
	CircularArrayQueue
	Codes
	EmpyCollectionExeception
	QueueADT
It did not state in the requirement to hand the above in (we did not have to modify any of these to begin with), and I'm sure you probably already know that these are needed. Actually I am not 100% sure if these are required to be in the same folder, I'm just basing this off the fact that the labs won't work unless these are included.

Thank you