//package Assignment1.assign1;
/**
 * interface. it is abstract and convertGrade is overridden in the other classes
 * @author Vivian A. Lam
 *
 */
public interface People {

	String convertGrade();

}
