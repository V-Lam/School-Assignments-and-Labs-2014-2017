Hello,

First off, I apologize if I over-commented. I don't know how much is too much commenting because I never got feedback from the TA and prof from 1026.

I wasn't sure if Javadoc is considered valid commenting. There are also normal comments within the code as well. I've invluded javaDoc files, but I am not entirely sure I did them correctly. It is not in the requirements so I hope that you do not penalize me, I am hoping that including them may count as a bonus.

Also, for question 1 it did not specify in the instructions to create getters and setters for the student class. It also doesn't specify handing in the UML diagram. I've included them anyways and I hope I don't get marks deducted for "not following instructions".

Thank you